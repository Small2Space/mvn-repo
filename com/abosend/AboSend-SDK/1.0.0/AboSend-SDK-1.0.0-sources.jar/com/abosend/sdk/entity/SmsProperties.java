package com.abosend.sdk.entity;

/**
 * @author Randy
 * @since 2025-02-19 14:08
 */
public class SmsProperties {
    private String orgCode;
    private String md5Key;

    public SmsProperties(String orgCode, String md5Key) {
        this.orgCode = orgCode;
        this.md5Key = md5Key;
    }

    public String getOrgCode() {
        return orgCode;
    }
    public String getMd5Key() {
        return md5Key;
    }

}
