//package com.abosend.sdk.util;
//
//import com.abosend.sdk.api.query.QueryService;
//import com.abosend.sdk.api.send.SendSmsService;
//import com.abosend.sdk.api.send.SendWhatsAppService;
//import com.abosend.sdk.entity.query.ApiQuerySendStatusModel;
//import com.abosend.sdk.entity.result.MessageResult;
//import com.abosend.sdk.entity.result.QueryOrgBalanceResult;
//import com.abosend.sdk.entity.result.QuerySendStatusResult;
//import com.abosend.sdk.entity.result.QueryWhatsAppAccountResult;
//import com.abosend.sdk.entity.sms.ApiSendSmsModel;
//import com.abosend.sdk.entity.sms.ApiV2SendSmsModel;
//import com.abosend.sdk.entity.whatsApp.ApiSendWhatsAppModel;
//
//import java.util.List;
//
//public class AboSendApiUtil {
//    static final String reqUrl = "https://xxxxx.com";
//    static final String orgCode = "Uxxxxx";
//    static final String md5Key = "XYFRXNXXXXXXXXXXXXXXXXXXXX";
//    static final QueryService queryService = new QueryService.Builder().setReqUrl(reqUrl).setOrgCode(orgCode).setMd5Key(md5Key).build();
//    static final SendSmsService sendSmsService = new SendSmsService.Builder().setReqUrl(reqUrl).setOrgCode(orgCode).setMd5Key(md5Key).build();
//    static final SendWhatsAppService sendWhatsAppService = new SendWhatsAppService.Builder().setReqUrl(reqUrl).setOrgCode(orgCode).setMd5Key(md5Key).build();
//
//    public static MessageResult sendSms(String content, String mobiles) {
//        ApiSendSmsModel param = new ApiSendSmsModel(content, mobiles);
//        return sendSmsService.sendSms(param);
//    }
//
//    public static MessageResult sendSmsV2(String content, String mobiles) {
//        ApiV2SendSmsModel param = new ApiV2SendSmsModel(content, mobiles);
//        return sendSmsService.sendSmsV2(param);
//    }
//
//    public static MessageResult sendWhatsAppMessages(String mobiles, String whatsAppSender, String templateId, List<String> templateParameter) {
//        ApiSendWhatsAppModel param = new ApiSendWhatsAppModel(mobiles, whatsAppSender, templateId, templateParameter);
//        return sendWhatsAppService.sendWhatsAppMessages(param);
//    }
//
//    public static QueryWhatsAppAccountResult queryWhatsAppAccount() {
//        return sendWhatsAppService.queryWhatsAppAccount();
//    }
//
//    public static QuerySendStatusResult querySendStatus(String sendCode) {
//        ApiQuerySendStatusModel querySendStatusModel = new ApiQuerySendStatusModel(sendCode);
//        return queryService.querySendStatus(querySendStatusModel);
//    }
//
//    public static QueryOrgBalanceResult queryOrgBalance() {
//        return queryService.queryOrgBalance();
//    }
//}
