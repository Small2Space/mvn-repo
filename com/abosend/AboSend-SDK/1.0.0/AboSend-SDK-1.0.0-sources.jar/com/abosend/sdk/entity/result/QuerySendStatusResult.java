package com.abosend.sdk.entity.result;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.List;
public class QuerySendStatusResult {
    @JsonProperty("code")
    private Integer code;

    @JsonProperty("data")
    private List<MessageDataDetails> data;

    public Integer getCode() {
        return code;
    }

    public List<MessageDataDetails> getData() {
        return data;
    }

    public static class MessageDataDetails {
        @JsonProperty("mobileArea")
        private String mobileArea;

        @JsonProperty("mobile")
        private String mobile;

        @JsonProperty("state")
        private String state;

        @JsonProperty("msg")
        private String msg;

        @JsonProperty("orgCode")
        private String orgCode;

        @JsonProperty("sendCode")
        private String sendCode;

        public String getMobileArea() {
            return mobileArea;
        }

        public String getMobile() {
            return mobile;
        }

        public String getState() {
            return state;
        }

        public String getMsg() {
            return msg;
        }

        public String getOrgCode() {
            return orgCode;
        }

        public String getSendCode() {
            return sendCode;
        }
    }
}
