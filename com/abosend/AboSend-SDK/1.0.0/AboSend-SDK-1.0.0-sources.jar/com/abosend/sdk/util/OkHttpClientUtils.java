package com.abosend.sdk.util;

import okhttp3.OkHttpClient;

import java.util.concurrent.TimeUnit;

/**
 * @author Randy
 * @since 2025-03-21 17:23
 */
public class OkHttpClientUtils {

    public static OkHttpClient getOkHttpClient() {
        return new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)  // 連接超時 30 秒
                .readTimeout(30, TimeUnit.SECONDS)    // 讀取超時 30 秒
                .writeTimeout(30, TimeUnit.SECONDS)   // 寫入超時 30 秒
                .build();
    }
}
