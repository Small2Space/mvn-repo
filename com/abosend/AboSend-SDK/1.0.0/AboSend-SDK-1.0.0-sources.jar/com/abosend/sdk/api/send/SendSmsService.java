package com.abosend.sdk.api.send;


import com.abosend.sdk.codec.CustomErrorDecoder;
import com.abosend.sdk.codec.InheritedFormEncoder;
import com.abosend.sdk.entity.SmsProperties;
import com.abosend.sdk.entity.result.MessageResult;
import com.abosend.sdk.entity.sms.ApiSendSmsModel;
import com.abosend.sdk.entity.sms.ApiV2SendSmsModel;
import com.abosend.sdk.entity.sms.BaseSendSmsModel;
import com.abosend.sdk.httpClient.SendSmsClient;
import com.abosend.sdk.log.CustomSlf4jLogger;
import com.abosend.sdk.util.MD5Util;
import com.abosend.sdk.util.MobileNumberUtils;
import com.abosend.sdk.util.OkHttpClientUtils;
import com.abosend.sdk.util.RandomUtil;
import feign.Feign;
import feign.Logger;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import feign.okhttp.OkHttpClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.constraints.NotBlank;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Randy
 * @since 2025-02-19 11:30
 */
public class SendSmsService {
    private final SendSmsClient jsonClient;
    private final SendSmsClient formClient;
    private final SmsProperties properties;
    private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
    private final org.slf4j.Logger logger = LoggerFactory.getLogger(SendSmsService.class);


    public SendSmsService(SendSmsClient jsonClient, SendSmsClient formClient, SmsProperties properties) {
        this.jsonClient = jsonClient;
        this.formClient = formClient;
        this.properties = properties;
    }

    /**
     * Send Sms By application/x-www-form-urlencoded
     *
     * @param sendSmsModel ApiSendSmsModel
     * @return MessageResult
     */
    public MessageResult sendSms(ApiSendSmsModel sendSmsModel) {
        // Call the verification method
        validateSmsRequest(sendSmsModel);
        String mobileNumbers = MobileNumberUtils.validateMobileNumbers(sendSmsModel.getMobiles());
        sendSmsModel.setMobiles(mobileNumbers);

        //Content passed twice url encode
        try {
            String content = URLEncoder.encode(URLEncoder.encode(sendSmsModel.getContent(), StandardCharsets.UTF_8.name()), StandardCharsets.UTF_8.name());
            sendSmsModel.setContent(content);
        } catch (UnsupportedEncodingException e) {
            throw new RuntimeException(e);
        }
        logger.info("orgCode:{}, md5Key:{}, content:{}, mobiles:{}, rand:{}, oaNumber:{}, notifyUrl:{}, sign:{}",
                sendSmsModel.getOrgCode(), properties.getMd5Key(), sendSmsModel.getContent(), sendSmsModel.getMobiles(), sendSmsModel.getRand(), sendSmsModel.getOaNumber(), sendSmsModel.getNotifyUrl(), sendSmsModel.getSign());
        return formClient.sendSms(sendSmsModel);
    }

    /**
     * Send Sms By application/JSON
     *
     * @param sendSmsModel ApiSendSmsModel
     * @return MessageResult
     */
    public MessageResult sendSmsV2(ApiV2SendSmsModel sendSmsModel) {
        // Call the verification method
        validateSmsRequest(sendSmsModel);
        String mobileNumbers = MobileNumberUtils.validateMobileNumbers(sendSmsModel.getMobiles());
        sendSmsModel.setMobiles(mobileNumbers);

        logger.info("orgCode:{}, md5Key:{}, content:{}, mobiles:{}, rand:{} oaNumber:{}, notifyUrl:{}, sign:{}",
                sendSmsModel.getOrgCode(), properties.getMd5Key(), sendSmsModel.getContent(), sendSmsModel.getMobiles(), sendSmsModel.getRand(), sendSmsModel.getOaNumber(), sendSmsModel.getNotifyUrl(), sendSmsModel.getSign());
        return jsonClient.sendSmsV2(sendSmsModel);
    }

    private <T extends BaseSendSmsModel> void validateSmsRequest(T sendSmsModel) {
        Set<ConstraintViolation<T>> violations = validator.validate(sendSmsModel);
        if (!violations.isEmpty()) {
            String errorMsg = violations.stream()
                    .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                    .collect(Collectors.joining("; "));
            throw new IllegalArgumentException("Send Sms Model Verification Failed: " + errorMsg);
        }

        if (StringUtils.isBlank(sendSmsModel.getOrgCode())) {
            sendSmsModel.setOrgCode(properties.getOrgCode());
        }
        if (StringUtils.isBlank(sendSmsModel.getRand())) {
            sendSmsModel.setRand(RandomUtil.generateSixDigitCode());
        }
        if (StringUtils.isBlank(sendSmsModel.getSign())) {
            //sign = MD5(orgCode+content+rand+MD5key)
            sendSmsModel.setSign(MD5Util.MD5(sendSmsModel.getOrgCode() + sendSmsModel.getContent() + sendSmsModel.getRand() + properties.getMd5Key()));
        }
    }

    public static class Builder {
        private String reqUrl;
        private String orgCode;
        private String md5Key;

        public Builder setReqUrl(@NotBlank String reqUrl) {
            this.reqUrl = reqUrl;
            return this;
        }

        public Builder setOrgCode(@NotBlank String orgCode) {
            this.orgCode = orgCode;
            return this;
        }

        public Builder setMd5Key(@NotBlank String md5Key) {
            this.md5Key = md5Key;
            return this;
        }

        public SendSmsService build() {
            SendSmsClient jsonClient = Feign.builder()
                    .client(new OkHttpClient(OkHttpClientUtils.getOkHttpClient()))
                    .encoder(new JacksonEncoder())  // 处理 JSON
                    .decoder(new JacksonDecoder())
                    .errorDecoder(new CustomErrorDecoder())
                    // 先不引入重試機制
                    //.retryer(new Retryer.Default(100, 1000, 3)) // 初始延遲100ms，最大延遲1秒，最多重試3次
                    .logger(new CustomSlf4jLogger())
                    .logLevel(Logger.Level.FULL)
                    .target(SendSmsClient.class, reqUrl);

            SendSmsClient formClient = Feign.builder()
                    .client(new OkHttpClient(OkHttpClientUtils.getOkHttpClient()))
                    .encoder(new InheritedFormEncoder())  // 处理 application/x-www-form-urlencoded
                    .decoder(new JacksonDecoder())
                    .errorDecoder(new CustomErrorDecoder())
                    // 先不引入重試機制
                    //.retryer(new Retryer.Default(1000, 10000, 5)) // 初始延遲100ms，最大延遲1秒，最多重試3次
                    .logger(new CustomSlf4jLogger())
                    .logLevel(Logger.Level.FULL)
                    .target(SendSmsClient.class, reqUrl);

            SmsProperties properties = new SmsProperties(orgCode, md5Key);
            return new SendSmsService(jsonClient, formClient, properties);
        }
    }
}
