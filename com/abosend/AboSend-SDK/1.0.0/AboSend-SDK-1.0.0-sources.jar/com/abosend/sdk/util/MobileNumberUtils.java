package com.abosend.sdk.util;

import org.apache.commons.lang3.StringUtils;

/**
 * @author Randy
 * @since 2025-02-21 10:38
 */
public class MobileNumberUtils {
    private static final int MAX_MOBILE_COUNT = 1000;

    /**
     * Validates and formats a string of mobile numbers.
     * The numbers should be separated by commas (`,`), and leading or trailing commas are removed before validation.
     * If the total count exceeds 1000, an {@link IllegalArgumentException} is thrown.
     *
     * @param mobiles A string containing multiple phone numbers separated by commas.
     * @return A trimmed and validated mobile number string.
     * @throws IllegalArgumentException if the number of phone numbers exceeds the limit of 1000.
     */
    public static String validateMobileNumbers(String mobiles) {
        if (StringUtils.isBlank(mobiles)) {
            throw new IllegalArgumentException("Mobile numbers cannot be null or empty.");
        }

        // Remove leading/trailing commas and spaces
        String formattedMobiles = mobiles.trim().replaceAll("^,|,$", "");

        // Count phone numbers based on commas
        long count = formattedMobiles.chars().filter(ch -> ch == ',').count() + 1;

        if (count > MAX_MOBILE_COUNT) {
            throw new IllegalArgumentException("Mobile number limit exceeded (max " + MAX_MOBILE_COUNT + ").");
        }
        return formattedMobiles;
    }
}
