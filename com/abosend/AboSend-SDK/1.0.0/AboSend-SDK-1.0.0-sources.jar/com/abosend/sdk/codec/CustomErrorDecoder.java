package com.abosend.sdk.codec;

import feign.Response;
import feign.RetryableException;
import feign.codec.ErrorDecoder;

import java.util.Date;

/**
 * 自定義錯誤解析器 目前先解析503(bad gateway)
 *
 * @author Randy
 * @since 2025-03-13 11:02
 */
public class CustomErrorDecoder implements ErrorDecoder {

    private final ErrorDecoder defaultErrorDecoder = new Default();

    @Override
    public Exception decode(String methodKey, Response response) {
        switch (response.status()) {
            case 503:
                return new RetryableException( "The service is temporarily unavailable, please try again later", response.request().httpMethod(),
                        new Date());
            default:
                return defaultErrorDecoder.decode(methodKey, response);
        }
    }
}
