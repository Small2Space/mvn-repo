package com.abosend.sdk.api.query;


import com.abosend.sdk.codec.CustomErrorDecoder;
import com.abosend.sdk.codec.InheritedFormEncoder;
import com.abosend.sdk.entity.SmsProperties;
import com.abosend.sdk.entity.query.ApiQueryBalanceOrgModel;
import com.abosend.sdk.entity.query.ApiQuerySendStatusModel;
import com.abosend.sdk.entity.result.QueryOrgBalanceResult;
import com.abosend.sdk.entity.result.QuerySendStatusResult;
import com.abosend.sdk.httpClient.SendSmsClient;
import com.abosend.sdk.log.CustomSlf4jLogger;
import com.abosend.sdk.util.MD5Util;
import com.abosend.sdk.util.OkHttpClientUtils;
import com.abosend.sdk.util.RandomUtil;
import feign.Feign;
import feign.Logger;
import feign.jackson.JacksonDecoder;
import feign.okhttp.OkHttpClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.constraints.NotBlank;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Randy
 * @since 2025-02-19 11:30
 */
public class QueryService {
    private final SendSmsClient formClient;
    private final SmsProperties properties;
    private static final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
    private final org.slf4j.Logger logger = LoggerFactory.getLogger(QueryService.class);

    public QueryService(SendSmsClient formClient, SmsProperties properties) {
        this.formClient = formClient;
        this.properties = properties;
    }

    /**
     * Query Send Status
     *
     * @param querySendStatusModel ApiQuerySendStatusModel
     * @return QuerySendStatusResult
     */
    public QuerySendStatusResult querySendStatus(ApiQuerySendStatusModel querySendStatusModel) {
        // Call the verification method
        validateQueryRequest(querySendStatusModel);

        if (StringUtils.isNotBlank(querySendStatusModel.getMobileArea()) && StringUtils.isNotBlank(querySendStatusModel.getMobile())) {
            try {
                String mobileArea = URLEncoder.encode(querySendStatusModel.getMobileArea(), StandardCharsets.UTF_8.name());
                querySendStatusModel.setMobileArea(mobileArea);
                querySendStatusModel.setMobile(querySendStatusModel.getMobile());
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
        logger.info("orgCode:{}, md5Key:{}, sendCode:{}, mobileArea:{}, mobile:{}, rand:{}", querySendStatusModel.getOrgCode(), properties.getMd5Key(), querySendStatusModel.getSendCode(), querySendStatusModel.getMobileArea(), querySendStatusModel.getMobile(), querySendStatusModel.getRand());
        return formClient.querySendStatus(querySendStatusModel);
    }

    /**
     * Query Organization Balance
     *
     * @return QueryOrgBalanceResult
     */
    public QueryOrgBalanceResult queryOrgBalance() {
        ApiQueryBalanceOrgModel queryBalanceOrgModel = new ApiQueryBalanceOrgModel(properties);
        logger.info("orgCode:{}, md5Key:{}, rand:{}, sign:{}", properties.getOrgCode(), properties.getMd5Key(), queryBalanceOrgModel.getRand(), queryBalanceOrgModel.getSign());
        return formClient.queryOrgBalance(queryBalanceOrgModel);
    }

    private void validateQueryRequest(ApiQuerySendStatusModel querySendStatusModel) {
        Set<ConstraintViolation<ApiQuerySendStatusModel>> violations = validator.validate(querySendStatusModel);
        if (!violations.isEmpty()) {
            String errorMsg = violations.stream()
                    .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                    .collect(Collectors.joining("; "));
            throw new IllegalArgumentException("Parameter verification failed: " + errorMsg);
        }

        if (querySendStatusModel.getMobileArea() != null && querySendStatusModel.getMobile() == null) {
            throw new IllegalArgumentException("please enter your phone number");
        } else if (querySendStatusModel.getMobileArea() == null && querySendStatusModel.getMobile() != null) {
            throw new IllegalArgumentException("please enter phone number area");
        }

        if (StringUtils.isBlank(querySendStatusModel.getOrgCode())) {
            querySendStatusModel.setOrgCode(properties.getOrgCode());
        }
        if (StringUtils.isBlank(querySendStatusModel.getRand())) {
            querySendStatusModel.setRand(RandomUtil.generateSixDigitCode());
        }
        if (StringUtils.isBlank(querySendStatusModel.getSign())) {
            //sign = MD5(orgCode+rand+sendCode+MD5key)
            querySendStatusModel.setSign(MD5Util.MD5(querySendStatusModel.getOrgCode() + querySendStatusModel.getRand() + querySendStatusModel.getSendCode() + properties.getMd5Key()));
        }
    }

    public static class Builder {
        private String reqUrl;
        private String orgCode;
        private String md5Key;

        public Builder setReqUrl(@NotBlank String reqUrl) {
            this.reqUrl = reqUrl;
            return this;
        }

        public Builder setOrgCode(@NotBlank String orgCode) {
            this.orgCode = orgCode;
            return this;
        }

        public Builder setMd5Key(@NotBlank String md5Key) {
            this.md5Key = md5Key;
            return this;
        }

        public QueryService build() {
            Set<ConstraintViolation<Builder>> violations = validator.validate(this);
            if (!violations.isEmpty()) {
                throw new IllegalArgumentException("参数校验失败: " + violations.iterator().next().getMessage());
            }
            SendSmsClient formClient = Feign.builder()
                    .client(new OkHttpClient(OkHttpClientUtils.getOkHttpClient()))
                    .encoder(new InheritedFormEncoder())  // 处理 application/x-www-form-urlencoded
                    .decoder(new JacksonDecoder())
                    .logger(new CustomSlf4jLogger())
                    .errorDecoder(new CustomErrorDecoder())
                    // 先不引入重試機制
                    //.retryer(new Retryer.Default(100, 1000, 3)) // 初始延遲100ms，最大延遲1秒，最多重試3次
                    .logLevel(Logger.Level.FULL)
                    .target(SendSmsClient.class, reqUrl);

            SmsProperties properties = new SmsProperties(orgCode, md5Key);
            return new QueryService(formClient, properties);
        }
    }
}
