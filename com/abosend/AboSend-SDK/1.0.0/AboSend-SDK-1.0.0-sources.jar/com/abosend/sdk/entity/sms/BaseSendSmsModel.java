package com.abosend.sdk.entity.sms;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;


/**
 * @author Randy
 * @since 2025-02-20 15:40
 */
public class BaseSendSmsModel {
    /**
     * Organization code
     */
    private String orgCode;

    /**
     * Recipient phone numbers.
     *
     * <p>The phone numbers must include the country/region code and be placed before the phone number.</p>
     *
     * <p><strong>Example:</strong> <code>+85212345678</code></p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>The "+" symbol is <strong>NOT</strong> necessary in the phone number.</li>
     *   <li>For multiple phone numbers, separate them using an English comma (<code>,</code>).</li>
     *   <li>A maximum of <strong>500</strong> phone numbers can be included.</li>
     * </ul>
     */
    @NotBlank(message = "mobiles cannot be empty")
    private String mobiles;

    /**
     * SMS Content
     */
    @NotBlank(message = "SMS content cannot be empty")
    @Size(max = 2048, message = "SMS content no more than 500 words")
    private String content;

    /**
     * 6 digit random numbers
     */
    private String rand;

    /**
     * Generates a signature using the MD5 algorithm.
     *
     * <p>Signature formula: <code>Signature = MD5(orgCode + content + rand + MD5key)</code></p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>The generated value must be 32 characters in length and in all uppercase.</li>
     *   <li><code>MD5Key</code> can be retrieved from the organization information in the home dashboard
     *       after logging into the merchant control panel.</li>
     * </ul>
     */
    private String sign;

    /**
     * Callback URL.
     *
     * <p>If automatic delivery receipt (DR) return is required, please provide the callback URL.</p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>If this parameter is not provided, the DR will be returned to the default callback URL configured in the system.</li>
     * </ul>
     */
    private String notifyUrl;

    /**
     * SenderID. ONLY available for specific service providers. Please contact admin to get further information.
     */
    private String oaNumber;

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getMobiles() {
        return mobiles;
    }

    public void setMobiles(String mobiles) {
        this.mobiles = mobiles;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getRand() {
        return rand;
    }

    public void setRand(String rand) {
        this.rand = rand;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }

    public String getOaNumber() {
        return oaNumber;
    }

    public void setOaNumber(String oaNumber) {
        this.oaNumber = oaNumber;
    }

}
