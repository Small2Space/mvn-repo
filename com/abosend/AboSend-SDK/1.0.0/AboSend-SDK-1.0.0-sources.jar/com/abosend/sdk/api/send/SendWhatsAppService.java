package com.abosend.sdk.api.send;


import com.abosend.sdk.codec.CustomErrorDecoder;
import com.abosend.sdk.entity.SmsProperties;
import com.abosend.sdk.entity.query.ApiQueryWhatsAppAccountModel;
import com.abosend.sdk.entity.result.MessageResult;
import com.abosend.sdk.entity.result.QueryWhatsAppAccountResult;
import com.abosend.sdk.entity.whatsApp.ApiSendWhatsAppModel;
import com.abosend.sdk.httpClient.SendSmsClient;
import com.abosend.sdk.log.CustomSlf4jLogger;
import com.abosend.sdk.util.MD5Util;
import com.abosend.sdk.util.MobileNumberUtils;
import com.abosend.sdk.util.OkHttpClientUtils;
import com.abosend.sdk.util.RandomUtil;
import feign.Feign;
import feign.Logger;
import feign.jackson.JacksonDecoder;
import feign.jackson.JacksonEncoder;
import feign.okhttp.OkHttpClient;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.constraints.NotBlank;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * @author Randy
 * @since 2025-02-19 11:30
 */
public class SendWhatsAppService {
    private final SendSmsClient jsonClient;
    private final SmsProperties properties;
    private static final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
    private final org.slf4j.Logger logger = LoggerFactory.getLogger(SendWhatsAppService.class);

    public SendWhatsAppService(SendSmsClient jsonClient, SmsProperties properties) {
        this.properties = properties;
        this.jsonClient = jsonClient;
    }

    /**
     * Send WhatsApp Messages
     *
     * @param sendWhatsAppModel ApiSendWhatsAppModel
     * @return MessageResult
     */
    public MessageResult sendWhatsAppMessages(ApiSendWhatsAppModel sendWhatsAppModel) {
        // Call the verification method
        validateWhatsAppMsgRequest(sendWhatsAppModel);
        String mobileNumbers = MobileNumberUtils.validateMobileNumbers(sendWhatsAppModel.getMobiles());
        sendWhatsAppModel.setMobiles(mobileNumbers);

        logger.info("orgCode:{}, md5Key:{}, templateParameter:{}, mobiles:{}, whatsAppSender:{}, rand:{}, notifyUrl:{}, sign:{}%n",
                sendWhatsAppModel.getOrgCode(), properties.getMd5Key(), sendWhatsAppModel.getTemplateParameter(), sendWhatsAppModel.getMobiles(), sendWhatsAppModel.getWhatsAppSender(), sendWhatsAppModel.getRand(), sendWhatsAppModel.getNotifyUrl(), sendWhatsAppModel.getSign());
        return jsonClient.sendWhatsAppMessages(sendWhatsAppModel);
    }

    /**
     * Query WhatsApp Account Result
     *
     * @return QueryWhatsAppAccountResult
     */
    public QueryWhatsAppAccountResult queryWhatsAppAccount() {
        ApiQueryWhatsAppAccountModel queryWhatsAppAccountModel = new ApiQueryWhatsAppAccountModel(properties);
        logger.info("orgCode:{}, md5Key:{}, sign:{}%n", properties.getOrgCode(), properties.getMd5Key(), queryWhatsAppAccountModel.getSign());
        return jsonClient.queryWhatsAppAccount(queryWhatsAppAccountModel);
    }

    private void validateWhatsAppMsgRequest(ApiSendWhatsAppModel sendWhatsAppModel) {
        Set<ConstraintViolation<ApiSendWhatsAppModel>> violations = validator.validate(sendWhatsAppModel);
        if (!violations.isEmpty()) {
            String errorMsg = violations.stream()
                    .map(v -> v.getPropertyPath() + ": " + v.getMessage())
                    .collect(Collectors.joining("; "));
            throw new IllegalArgumentException("Parameter verification failed: " + errorMsg);
        }

        if (StringUtils.isBlank(sendWhatsAppModel.getOrgCode())) {
            sendWhatsAppModel.setOrgCode(properties.getOrgCode());
        }
        if (StringUtils.isBlank(sendWhatsAppModel.getRand())) {
            sendWhatsAppModel.setRand(RandomUtil.generateSixDigitCode());
        }
        if (StringUtils.isBlank(sendWhatsAppModel.getSign())) {
            // sign = MD5(orgCode+templateId+rand+MD5key)
            sendWhatsAppModel.setSign(MD5Util.MD5(sendWhatsAppModel.getOrgCode() + sendWhatsAppModel.getTemplateId() + sendWhatsAppModel.getRand() + properties.getMd5Key()));
        }
    }

    public static class Builder {
        private String reqUrl;
        private String orgCode;
        private String md5Key;

        public Builder setReqUrl(@NotBlank String reqUrl) {
            this.reqUrl = reqUrl;
            return this;
        }

        public Builder setOrgCode(@NotBlank String orgCode) {
            this.orgCode = orgCode;
            return this;
        }

        public Builder setMd5Key(@NotBlank String md5Key) {
            this.md5Key = md5Key;
            return this;
        }

        public SendWhatsAppService build() {
            Set<ConstraintViolation<Builder>> violations = validator.validate(this);
            if (!violations.isEmpty()) {
                throw new IllegalArgumentException("参数校验失败: " + violations.iterator().next().getMessage());
            }

            SendSmsClient jsonClient = Feign.builder()
                    .client(new OkHttpClient(OkHttpClientUtils.getOkHttpClient()))
                    .encoder(new JacksonEncoder())  // 处理 JSON
                    .decoder(new JacksonDecoder())
                    .errorDecoder(new CustomErrorDecoder())
                    // 先不引入重試機制
                    //.retryer(new Retryer.Default(100, 1000, 3)) // 初始延遲100ms，最大延遲1秒，最多重試3次
                    .logger(new CustomSlf4jLogger())
                    .logLevel(Logger.Level.FULL)
                    .target(SendSmsClient.class, reqUrl);

            SmsProperties properties = new SmsProperties(orgCode, md5Key);
            return new SendWhatsAppService(jsonClient, properties);
        }
    }
}
