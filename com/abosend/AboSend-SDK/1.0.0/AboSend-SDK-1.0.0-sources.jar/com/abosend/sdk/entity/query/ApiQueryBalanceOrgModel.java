package com.abosend.sdk.entity.query;

import com.abosend.sdk.entity.SmsProperties;
import com.abosend.sdk.util.MD5Util;
import com.abosend.sdk.util.RandomUtil;

/**
 * @author Randy
 * @since 2025-02-19 11:30
 */
public class ApiQueryBalanceOrgModel {
    /**
     * Organization code
     */
    private String orgCode;

    /**
     * 6 digit random numbers
     */
    private String rand;

    /**
     * Generates a signature using the MD5 algorithm.
     *
     * <p>Signature formula: <code>Signature = MD5(orgCode + rand + MD5key)</code></p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>The generated value must be 32 characters in length and in all uppercase.</li>
     *   <li><code>MD5Key</code> can be retrieved from the organization information in the home dashboard
     *       after logging into the merchant control panel.</li>
     * </ul>
     */
    private String sign;

    public String getOrgCode() {
        return orgCode;
    }

    public String getRand() {
        return rand;
    }

    public String getSign() {
        return sign;
    }

    public ApiQueryBalanceOrgModel() {
    }

    public ApiQueryBalanceOrgModel(SmsProperties properties) {
        this.orgCode = properties.getOrgCode();
        this.rand = RandomUtil.generateSixDigitCode();
        //sign = MD5(orgCode+rand+MD5key)
        this.sign = MD5Util.MD5(this.orgCode + this.rand + properties.getMd5Key());
    }
}
