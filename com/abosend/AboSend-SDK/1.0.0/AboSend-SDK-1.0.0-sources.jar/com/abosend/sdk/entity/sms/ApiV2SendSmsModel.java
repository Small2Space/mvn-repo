package com.abosend.sdk.entity.sms;

public class ApiV2SendSmsModel extends BaseSendSmsModel {
    public ApiV2SendSmsModel() {
    }

    public ApiV2SendSmsModel(String content, String mobiles) {
        super.setContent(content);
        super.setMobiles(mobiles);
    }
}
