package com.abosend.sdk.entity.result;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author Randy
 * @since 2025-02-26 10:16
 */
public class QueryWhatsAppAccountResult {
    @JsonProperty("code")
    private Integer code;

    @JsonProperty("data")
    private WhatsAppAccountData data;

    public Integer getTotal() {
        return Objects.isNull(data) ? 0 : data.total;
    }

    public List<WhatsAppAccountDataDetails> getWhatsAppAccountDataDetailsList() {
        return Objects.isNull(data) ? new ArrayList<>() : data.whatsAppAccountDataDetailsList;
    }

    public Integer getCode() {
        return code;
    }

    public static class WhatsAppAccountData {
        @JsonProperty("total")
        private Integer total;

        @JsonProperty("whatsAppAccount")
        private List<WhatsAppAccountDataDetails> whatsAppAccountDataDetailsList;
    }

    public static class WhatsAppAccountDataDetails {
        @JsonProperty("accountName")
        private String accountName;

        @JsonProperty("phoneNumber")
        private String phoneNumber;

        public String getAccountName() {
            return accountName;
        }

        public String getPhoneNumber() {
            return phoneNumber;
        }
    }
}


