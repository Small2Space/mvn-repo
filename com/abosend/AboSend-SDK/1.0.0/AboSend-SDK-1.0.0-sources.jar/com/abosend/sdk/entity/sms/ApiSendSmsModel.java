package com.abosend.sdk.entity.sms;


public class ApiSendSmsModel extends BaseSendSmsModel {
    /**
     * Country/Region code; use V1
     */
    private final String mobileArea = "%2B0";

    public ApiSendSmsModel() {
    }

    public ApiSendSmsModel(String content, String mobiles) {
        super.setContent(content);
        super.setMobiles(mobiles);
    }
}
