package com.abosend.sdk.entity.whatsApp;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.validation.constraints.NotBlank;
import java.util.List;

public class ApiSendWhatsAppModel {
    /**
     * Organization code
     */
    @JsonProperty("orgCode")
    private String orgCode;

    /**
     * Recipient phone numbers.
     *
     * <p>The phone numbers must include the country/region code and be placed before the phone number.</p>
     *
     * <p><strong>Example:</strong> <code>+85212345678</code></p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>The "+" symbol is <strong>NOT</strong> necessary in the phone number.</li>
     *   <li>For multiple phone numbers, separate them using an English comma (<code>,</code>).</li>
     *   <li>A maximum of <strong>500</strong> phone numbers can be included.</li>
     * </ul>
     */
    @JsonProperty("mobiles")
    @NotBlank(message = "mobiles cannot be empty")
    private String mobiles;

    /**
     * Template ID
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>Template ID will show in “WhatsApp Templates” page on the platform.</li>
     * </ul>
     */

    @JsonProperty("templateId")
    @NotBlank(message = "templateId cannot be empty")
    private String templateId;

    /**
     * Variable Character in Template Content
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *     <li>If there is more than one "Variable Character", please follow the template order.</li>
     *     <li>The number of "Variable Characters" filled in this column cannot be less than required by the template.</li>
     * </ul>
     */
    @JsonProperty("templateParameter")
    private List<String> templateParameter;

    /**
     * 6 digit random numbers
     */
    @JsonProperty("rand")
    private String rand;

    /**
     * Generates a signature using the MD5 algorithm.
     *
     * <p>Signature formula: <code>Signature = MD5(orgCode + templateId + rand + MD5key)</code></p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>The generated value must be 32 characters in length and in all uppercase.</li>
     *   <li><code>MD5Key</code> can be retrieved from the organization information in the home dashboard
     *       after logging into the merchant control panel.</li>
     * </ul>
     */
    @JsonProperty("sign")
    private String sign;

    /**
     * Sender ID (SenderID)
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>WhatsApp Sender will show in “Broadcast” page on the platform or through the “Get WhatsApp Account” SendWhatsAppService->queryWhatsAppAccount to get the get the WhatsApp Sender.</li>
     * </ul>
     */
    @JsonProperty("whatsAppSender")
    @NotBlank(message = "whatsAppSender cannot be empty")
    private String whatsAppSender;

    /**
     * Callback URL.
     *
     * <p>If automatic delivery receipt (DR) return is required, please provide the callback URL.</p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>If this parameter is not provided, the DR will be returned to the default callback URL configured in the system.</li>
     * </ul>
     */
    @JsonProperty("notifyUrl")
    private String notifyUrl;

    public ApiSendWhatsAppModel() {
    }

    public ApiSendWhatsAppModel(String mobiles, String whatsAppSender, String templateId, List<String> templateParameter) {
        this.mobiles = mobiles;
        this.whatsAppSender = whatsAppSender;
        this.templateId = templateId;
        this.templateParameter = templateParameter;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getMobiles() {
        return mobiles;
    }

    public void setMobiles(String mobiles) {
        this.mobiles = mobiles;
    }

    public String getTemplateId() {
        return templateId;
    }

    public void setTemplateId(String templateId) {
        this.templateId = templateId;
    }

    public List<String> getTemplateParameter() {
        return templateParameter;
    }

    public void setTemplateParameter(List<String> templateParameter) {
        this.templateParameter = templateParameter;
    }

    public String getRand() {
        return rand;
    }

    public void setRand(String rand) {
        this.rand = rand;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getWhatsAppSender() {
        return whatsAppSender;
    }

    public void setWhatsAppSender(String whatsAppSender) {
        this.whatsAppSender = whatsAppSender;
    }

    public String getNotifyUrl() {
        return notifyUrl;
    }

    public void setNotifyUrl(String notifyUrl) {
        this.notifyUrl = notifyUrl;
    }
}
