package com.abosend.sdk.util;

import java.security.SecureRandom;
import java.util.Random;

public class RandomUtil {
    private static final Random RANDOM = new SecureRandom();

    /**
     * Generates a random numeric code with the specified length.
     *
     * @param length The number of digits in the generated code (must be &gt;= 1).
     * @return A randomly generated numeric code as a string.
     * @throws IllegalArgumentException If the length is less than 1.
     */
    public static String generateNumericCode(int length) {
        if (length < 1) {
            throw new IllegalArgumentException("Length must be at least 1");
        }
        int min = (int) Math.pow(10, length - 1);
        int max = (int) Math.pow(10, length) - 1;
        int code = min + RANDOM.nextInt(max - min + 1);
        return String.valueOf(code);
    }

    public static String generateSixDigitCode() {
        return generateNumericCode(6);
    }
}
