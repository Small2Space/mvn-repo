package com.abosend.sdk.entity.query;

import javax.validation.constraints.NotBlank;

/**
 * @author Randy
 * @since 2025-02-19 11:30
 */
public class ApiQuerySendStatusModel {
    /**
     * Organization code
     */
    private String orgCode;

    /**
     * 6 digit random numbers
     */
    private String rand;

    /**
     * Generates a signature using the MD5 algorithm.
     *
     * <p>Signature formula: <code>Signature = MD5(orgCode + rand + sendCode + MD5Key)</code></p>
     *
     * <p><strong>Remarks:</strong></p>
     * <ul>
     *   <li>The generated value must be 32 characters in length and in all uppercase.</li>
     *   <li><code>MD5Key</code> can be retrieved from the organization information in the home dashboard
     *       after logging into the merchant control panel.</li>
     * </ul>
     */
    private String sign;

    /**
     * SMS Send Code
     */
    @NotBlank(message = "send code cannot be empty")
    private String sendCode;

    /**
     * Country/Region code
     */
    private String mobileArea;

    /**
     * phone number
     */
    private String mobile;

    public ApiQuerySendStatusModel(String sendCode) {
        this.sendCode = sendCode;
    }

    public ApiQuerySendStatusModel(String sendCode, String mobileArea, String mobile) {
        this.sendCode = sendCode;
        this.mobileArea = mobileArea;
        this.mobile = mobile;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getRand() {
        return rand;
    }

    public void setRand(String rand) {
        this.rand = rand;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getSendCode() {
        return sendCode;
    }

    public void setSendCode(String sendCode) {
        this.sendCode = sendCode;
    }

    public String getMobileArea() {
        return mobileArea;
    }

    public void setMobileArea(String mobileArea) {
        this.mobileArea = mobileArea;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
