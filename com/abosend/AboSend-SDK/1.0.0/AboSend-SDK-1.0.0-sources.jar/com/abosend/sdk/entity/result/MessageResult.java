package com.abosend.sdk.entity.result;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class MessageResult {
    @JsonProperty("code")
    private Integer code;

    @JsonProperty("data")
    private SendCodeData data;

    @JsonProperty("message")
    private String message;

    public String getSendCode() {
        return Objects.isNull(data) ? "" : data.sendCode;
    }

    public static class SendCodeData {
        @JsonProperty("sendCode")
        private String sendCode;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
