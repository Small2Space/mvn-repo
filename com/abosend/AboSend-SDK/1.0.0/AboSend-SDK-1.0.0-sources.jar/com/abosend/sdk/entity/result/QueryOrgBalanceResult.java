package com.abosend.sdk.entity.result;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.Objects;

public class QueryOrgBalanceResult {
    @JsonProperty("code")
    private Integer code;

    @JsonProperty("data")
    private OrgBalance data;

    public String getOrgCode() {
        return Objects.isNull(data) ? "" : data.orgCode;
    }

    public String getBalance() {
        return Objects.isNull(data) ? "" : data.balance;
    }

    public static class OrgBalance {
        @JsonProperty("orgCode")
        private String orgCode;

        @JsonProperty("balance")
        private String balance;
    }

    public Integer getCode() {
        return code;
    }
}
