package com.abosend.sdk.log;

/**
 * @author Randy
 * @since 2025-02-20 17:32
 */

import feign.Logger;
import feign.Request;
import feign.Response;
import feign.Util;
import feign.slf4j.Slf4jLogger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class CustomSlf4jLogger extends Slf4jLogger {
    private final org.slf4j.Logger logger = LoggerFactory.getLogger(CustomSlf4jLogger.class);

    @Override
    protected void logRequest(String configKey, Logger.Level logLevel, Request request) {
        if (logLevel.ordinal() >= Logger.Level.BASIC.ordinal()) {
            // 输出请求地址
            logger.info("Request URL: {}", request.url());
            // 输出请求方法
            logger.info("Request Method: {}", request.httpMethod());

            //输出请求头中的 Content-Type
            String contentType = request.headers().get("Content-Type") != null ?
                    request.headers().get("Content-Type").toString() : "N/A";
            logger.info("Content-Type: {}", contentType);

            // 输出请求参数（请求体）
            if (request.body() != null) {
                String requestBody = new String(request.body(), StandardCharsets.UTF_8);
                logger.info("Request Body: {}", requestBody);
            } else {
                System.out.println("No request body.");
            }
        }
    }

    @Override
    protected Response logAndRebufferResponse(String configKey, Logger.Level logLevel, Response response, long elapsedTime) throws IOException {
        if (logLevel.ordinal() >= Logger.Level.BASIC.ordinal()) {
            // 输出响应状态码
            logger.info("Response Status: {}", response.status());

            // 输出响应体
            if (response.body() != null) {
                byte[] bodyData = Util.toByteArray(response.body().asInputStream());
                String responseBody = new String(bodyData, StandardCharsets.UTF_8);
                logger.info("Response Body: {}", responseBody);

                // 由于响应体只能读取一次，需要重新构造 Response 对象
                return response.toBuilder().body(bodyData).build();
            }
        }
        return response;
    }
}
