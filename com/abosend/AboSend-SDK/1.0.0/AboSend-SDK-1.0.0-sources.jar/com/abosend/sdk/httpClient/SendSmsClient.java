package com.abosend.sdk.httpClient;

import com.abosend.sdk.entity.query.ApiQueryBalanceOrgModel;
import com.abosend.sdk.entity.query.ApiQuerySendStatusModel;
import com.abosend.sdk.entity.query.ApiQueryWhatsAppAccountModel;
import com.abosend.sdk.entity.result.MessageResult;
import com.abosend.sdk.entity.result.QueryOrgBalanceResult;
import com.abosend.sdk.entity.result.QuerySendStatusResult;
import com.abosend.sdk.entity.result.QueryWhatsAppAccountResult;
import com.abosend.sdk.entity.sms.ApiSendSmsModel;
import com.abosend.sdk.entity.sms.ApiV2SendSmsModel;
import com.abosend.sdk.entity.whatsApp.ApiSendWhatsAppModel;
import feign.Headers;
import feign.RequestLine;

public interface SendSmsClient {
    /**
     * Send Sms V1
     *
     * @param sendSmsModel  Ap iSend Sms Model
     * @return Message Result
     */
    @RequestLine("POST api/sendSMS")
    @Headers("Content-Type: application/x-www-form-urlencoded")
    MessageResult sendSms(ApiSendSmsModel sendSmsModel);

    /**
     * Send Sms V2
     *
     * @param sendSmsModel Api V2 Send Sms Model
     * @return Message Result
     */
    @RequestLine("POST v2/api/sendSMS")
    @Headers("Content-Type: application/json; charset=utf-8")
    MessageResult sendSmsV2(ApiV2SendSmsModel sendSmsModel);

    /**
     * Send WhatsApp Message
     *
     * @param param Api Send WhatsApp Model
     * @return Message Result
     */
    @RequestLine("POST api/WhatsAppMessaging")
    @Headers("Content-Type: application/json; charset=utf-8")
    MessageResult sendWhatsAppMessages(ApiSendWhatsAppModel param);

    /**
     * Query WhatsApp Account
     *
     * @param queryWhatsAppAccountModel Query Param
     * @return Query WhatsApp Account Result
     */
    @RequestLine("POST api/getWhatsAppAccount")
    @Headers("Content-Type: application/json; charset=utf-8")
    QueryWhatsAppAccountResult queryWhatsAppAccount(ApiQueryWhatsAppAccountModel queryWhatsAppAccountModel);

    /**
     * Query Send Status
     *
     * @param querySendStatusModel Api Query Send Status Model
     * @return Query Send Status Result
     */
    @RequestLine("POST api/viewSendStatus")
    @Headers("Content-Type: application/x-www-form-urlencoded")
    QuerySendStatusResult querySendStatus(ApiQuerySendStatusModel querySendStatusModel);

    /**
     * Query Org Balance
     *
     * @param queryOrgBalanceModel Api Query Balance Org Model
     * @return Query Org Balance Result
     */
    @RequestLine("POST api/viewOrgBalance")
    @Headers("Content-Type: application/x-www-form-urlencoded")
    QueryOrgBalanceResult queryOrgBalance(ApiQueryBalanceOrgModel queryOrgBalanceModel);
}
