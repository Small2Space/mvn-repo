package com.abosend.sdk.codec;

import feign.RequestTemplate;
import feign.codec.Encoder;

import java.lang.reflect.Field;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

/**
 * @author Randy
 * @since 2025-02-20 18:02
 */
public class InheritedFormEncoder implements Encoder {

    @Override
    public void encode(Object object, Type bodyType, RequestTemplate template) {
        if (object == null) {
            return;
        }

        // 递归获取所有字段（包括父类）
        List<Field> allFields = getAllFields(object.getClass());

        // 构造 application/x-www-form-urlencoded 格式的请求体
        String formBody = allFields.stream()
                .peek(field -> field.setAccessible(true)) // 允许访问私有字段
                .map(field -> {
                    try {
                        Object value = field.get(object);
                        return value != null ? field.getName() + "=" + value.toString() : null;
                    } catch (IllegalAccessException e) {
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.joining("&"));

        // 设置请求体
        template.body(formBody.getBytes(StandardCharsets.UTF_8), StandardCharsets.UTF_8);
    }

    // 递归获取所有字段（包括父类）
    private List<Field> getAllFields(Class<?> clazz) {
        List<Field> fields = new ArrayList<>();
        while (clazz != null && clazz != Object.class) {
            fields.addAll(Arrays.asList(clazz.getDeclaredFields()));
            // 继续获取父类字段
            clazz = clazz.getSuperclass();
        }
        return fields;
    }
}

